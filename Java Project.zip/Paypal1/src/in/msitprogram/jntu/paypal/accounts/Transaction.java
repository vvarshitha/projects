package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable;

public class Transaction implements Serializable
{
	String tTime;
	String tDate;
	PPAccount account;
	String narration;
	String reference;
	String status;
	float debit;
	float credit;
	
	public String toString()
	{
		return tTime+"\t"+tDate+"\t\t"+account+"\t\t"+narration+"\t\t"+reference+"\t\t"+status+"\t\t"+debit+"\t\t"+credit;
	}
	public Transaction(String tTime,String tDate,PPAccount account,String narration,String reference,String status,float debit,float credit)
	{
		this.tTime=tTime;
		this.tDate=tDate;
		this.account=account;
		this.narration=narration;
		this.reference=reference;
		this.status=status;
		this.debit=debit;
		this.credit=credit;
		
	}
}
