/**
 * 
 */
package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.persistance.DataStore;

/**
 * @author pg
 *
 */
public class MainMenu {
	
	public static void show() throws Exception{
		//show the welcome message with the main menu options
		System.out.println("welcome to Paypall account");
		System.out.println(" 1. SIGN In \n 2. Creat New Account");
		Scanner sc = new Scanner(System.in);
		int N=sc.nextInt();
		switch(N)
		{
		case 1: System.out.println("SIGN In");
		        System.out.println("Enter EMAIL ID");
		        String email=sc.next();
		        PPAccountScreen ppa=new PPAccountScreen(email);
		        ppa.show();
		        break;
		case 2:System.out.println("Creat New Account");
               System.out.println("Enter EMAIL ID");
               String email1=sc.next();
               PPNewAccountScreen ppna=new PPNewAccountScreen(email1);
               ppna.show();
               break; 
		
		}
		//take the menu option as input from the console
		
		//take email address as input from the console
		
		//based on the given menu option instantiate the respective screens
	}

}
