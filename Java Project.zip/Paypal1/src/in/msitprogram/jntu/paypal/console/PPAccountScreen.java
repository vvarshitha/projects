package in.msitprogram.jntu.paypal.console;
import java.io.IOException;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.PPRestrictedAccount;
import in.msitprogram.jntu.paypal.accounts.Transaction;
import in.msitprogram.jntu.paypal.persistance.DataStore;


public class PPAccountScreen {
	PPAccount account;
	Scanner scan;
	int ch;
	boolean x;
	
	public PPAccountScreen(String email) throws Exception {
		scan = new Scanner(System.in);
		account = DataStore.lookupAccount(email);
	}

	public void show() throws Exception {
		
		//check if account is active
		if(account.isActivated())
		{
			System.out.println(account);
			System.out.println(" 1. Deposit \n 2. Withdraw\n3.suspension\n4.Transaction History\n5.requestMoney\n6.sendMoney");
			System.out.println("Enter any one option");
			Scanner sc = new Scanner(System.in);
			int k=sc.nextInt();
			switch(k)
			{
			case 1: addFunds();
			        DataStore.writeAccount(account);
			        MainMenu.show();
			        break;
			case 2: withdrawFunds();
			DataStore.writeAccount(account);
			        MainMenu.show();
			        break;
			case 3:System.out.println("do you want to suspend");
					System.out.println("\n1.yes\n2.no");
					System.out.println("Enter the choice");
					ch=sc.nextInt();
					if(ch==1)
					{
						 if(account!=null)
				          {
					        if(account.isActivated())
					        {
					        	account.setActivated(false);
					        	DataStore.writeAccount(account);
					        	System.out.println("your account is suspended");
					        	MainMenu.show();
					        }
				         }
					}
					else
					{
						MainMenu.show();
					}
			case 4:ArrayList<Transaction> al=new ArrayList<Transaction>();
	        al=account.getTransactions();
	        Iterator i=al.iterator();
		      System.out.println("\n Time\t\t Date \t\t Account \t\t Narration \t\t Reference \t\t Status \t\t Credit \t\t Debit ");
		       while(i.hasNext())
		       {
		    	   System.out.println(i.next());
		       }
		       MainMenu.show();
		       break;
		case 5:requestMoney();
			DataStore.writeAccount(account);
			MainMenu.show();
			break;
		case 6:sendMoney();
		DataStore.writeAccount(account);
		MainMenu.show();
		break;
		case 7:
			MainMenu.show();
			break; 
		}
			
	}
		else
		{
			System.out.println("Activate your Account");
		}
	}
	private void withdrawFunds() throws Exception {
		boolean y=true;
		if(account instanceof PPRestrictedAccount)
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter amount that you want to withdraw");
			float withdrawAmount=sc.nextFloat();
			float bal1=account.getAccountBal();
			if(withdrawAmount>5000)
			{
				System.out.println("Limit Crossed");
				y=false;
				MainMenu.show();
			}
			else
			{
				if(bal1>withdrawAmount)
				{
				    account.setAccountBal(account.getAccountBal()-withdrawAmount);
				    Date date = new Date();
					SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
					String tDate = formatter.format(date);
					 Date date1 = Calendar.getInstance().getTime();  
			         DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
			         String tTime = dateFormat.format(date1);  
			         String reference = account.getEmail();
					String narration="debit";
					String status;
					if(y==true)
					{
					 status="Debited";
					}
					else
					{
					 status="Not debited";
					}
					float credit=0;
					 float debit=withdrawAmount;
					Transaction t = new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
					account.setTransactions(t);
					DataStore.writeAccount(account);
					//System.out.println("Present balance is"+bal1);

				}
				else
				{
					System.out.println("Insufficient Funds");
					y=false;
					MainMenu.show();
				}
			}
			//account.setAccountBal(account.getAccountBal()+withdrawAmount);
			DataStore.writeAccount(account);
			System.out.println("Present balance is"+account.getAccountBal());
		}
		else
		{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter amount that you want to withdraw");
		float withdrawAmount=sc.nextFloat();
		float bal1=account.getAccountBal();
		if(bal1>withdrawAmount)
		{
		bal1=bal1-withdrawAmount;
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String tDate = formatter.format(date);
		 Date date1 = Calendar.getInstance().getTime();  
         DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
         String tTime = dateFormat.format(date1);  
         String reference = account.getEmail();
		String narration="debit";
		String status;
		if(y==true)
		{
		 status="Debited";
		}
		else
		{
		 status="Not debited";
		}
		float credit=0;
		 float debit=withdrawAmount;
		Transaction t =new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
		account.setTransactions(t);
		DataStore.writeAccount(account);
		System.out.println("Present balance is"+bal1);

		}
		else
		{
			System.out.println("Insufficient Funds");
			MainMenu.show();
		}
		account.setAccountBal(account.getAccountBal()-withdrawAmount);
		DataStore.writeAccount(account);
		System.out.println("Present balance is"+bal1);
		}
		// implement the withdraw funds user interface here
		
		//use the account object as needed for withdraw funds
		
	}

	private void requestMoney() throws Exception {
		// 	implement the request money user interface here
		//use the account object as needed for request money funds
		boolean y1=true;
		// 	implement the request money user interface here
		//use the account object as needed for request money funds
	    Scanner sc =new Scanner(System.in);
		System.out.println("Enter email of sender and Amount");
		String email=sc.next();
		float req=sc.nextFloat();
		PPAccount account1=DataStore.lookupAccount(email);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String tDate = formatter.format(date);
		 Date date1 = Calendar.getInstance().getTime();  
         DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
         String tTime = dateFormat.format(date1);  
         String reference1 = account1.getEmail();
         String reference = account.getEmail();
		String narration="Pending";
		String status;
		if(y1==true)
		{
		 status="Requested";
		}
		else
		{
		 status="Not Requested";
		}
		float credit=0;
		 float debit=0;
		Transaction t1 = new Transaction(tTime,tDate,account,narration,reference1,status,debit,credit);
		Transaction t = new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
		account1.setTransactions(t);
		account.setTransactions(t1);
		DataStore.writeAccount(account1);
		DataStore.writeAccount(account);

	}

	private void sendMoney() throws Exception {
		System.out.println("Enter Recepient mail and amount");
		boolean y1=true;
		Scanner sc = new Scanner(System.in);
		String email=sc.next();
		float amount=sc.nextInt();
		PPAccount account1=DataStore.lookupAccount(email);
		float bal1=account.getAccountBal();
		if(bal1>amount)
		{
		bal1=bal1-amount;
		account.setAccountBal(account.getAccountBal()-amount);
		account1.setAccountBal(account1.getAccountBal()+amount);
		float bal2=account1.getAccountBal();
		bal2=bal2+amount;
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String tDate = formatter.format(date);
		 Date date1 = Calendar.getInstance().getTime();  
         DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
         String tTime = dateFormat.format(date1);  
         String reference = account1.getEmail();
         String reference1 = account.getEmail();
		String narration="Transfer";
		String narration1="Received";
		String status;
		if(y1==true)
		{
		 status="Sent";
		}
		else
		{
		 status="Not Sent";
		}
		String status1="Received";
		float credit=0;
		float credit1=amount;
		 float debit=amount;
		 float debit1=0;
		Transaction t1 = new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
		Transaction t = new Transaction(tTime,tDate,account,narration1,reference1,status1,debit1,credit1);
		account1.setTransactions(t);
		account.setTransactions(t1);
		DataStore.writeAccount(account1);
		DataStore.writeAccount(account);
		}
		
		// implement the send moeny user interface here
		
		//use the account object as needed for send money funds
	}

	private void addFunds() throws IOException, ClassNotFoundException {
		boolean y1=true;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter amount that you want to add");
		float creditAm=sc.nextFloat();
		float bal=account.getAccountBal();
		bal=bal+creditAm;
		account.setAccountBal(account.getAccountBal()+creditAm);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String tDate = formatter.format(date);
		 Date date1 = Calendar.getInstance().getTime();  
         DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
         String tTime = dateFormat.format(date1);  
         String reference = account.getEmail();
		String narration="debit";
		String status;
		if(y1==true)
		{
		 status="Credited";
		}
		else
		{
		 status="not debited";
		}
		float credit=creditAm;
		 float debit=0;
		Transaction t = new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
		account.setTransactions(t);
		//DataStore.writeAccount(account);
		DataStore.writeAccount(account);
		System.out.println("Present balance is"+bal);
		
		// implement the add funds user interface here
		
		//use the account object as needed for add funds
	}

}
		//if active
		
			// print the account summary
			
			
			
			// print menu and accept menu options
			// for all the paypal account opera
		

	